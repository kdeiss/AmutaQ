icy_keepalive

Keep icy usb hardisk online.
This devices go offline after 20 minutes without activity - we try to keep unused devices online 

Other files inside this archive for testing and control icy hdd
